<div class="notice notice-error">
	<p><strong>Welcome to BeTheme</strong></p>
	<p>This version of Betheme is illegal, or <b>files have been corrupted</b>, and your data are not safe.</p>
  <p>For further details, please <b>contact us</b> at <a href="mailto:licenses@muffingroup.com">licenses@muffingroup.com</a></p>
</div>
